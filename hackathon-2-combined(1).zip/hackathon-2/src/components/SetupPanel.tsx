import { useState, useEffect } from 'react';
import { SubjectInput } from '../types';
import { SUBJECTS_BY_SECTION, SECTIONS, getDemoAttendanceForSubject, SEMESTER_START, SEMESTER_END } from '../data/timetable';
import { Logo } from './Logo';

interface SetupPanelProps {
  onGenerate: (data: {
    section: string;
    planningDate: string;
    subjects: SubjectInput[];
  }) => void;
  userSection: string;
}

export function SetupPanel({ onGenerate, userSection }: SetupPanelProps) {
  const [section, setSection] = useState(userSection);
  const [planningDate, setPlanningDate] = useState('');
  const [subjects, setSubjects] = useState<SubjectInput[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const today = new Date();

  useEffect(() => {
    const sectionSubjects = SUBJECTS_BY_SECTION[section] || [];
    const initial: SubjectInput[] = sectionSubjects.map((name, i) => {
      const demo = getDemoAttendanceForSubject(name);
      return {
        id: `subj-${i}`,
        name,
        attended: demo.attended,
        conducted: demo.conducted,
      };
    });
    setSubjects(initial);

    // Default planning date: 4 weeks from today
    const defaultPlan = new Date(today);
    defaultPlan.setDate(defaultPlan.getDate() + 28);
    const clamped = defaultPlan > SEMESTER_END ? SEMESTER_END : defaultPlan;
    setPlanningDate(clamped.toISOString().split('T')[0]);
  }, []);

  const semesterTotalDays = Math.ceil(
    (SEMESTER_END.getTime() - SEMESTER_START.getTime()) / (1000 * 60 * 60 * 24)
  );
  const semesterElapsedDays = Math.max(
    0,
    Math.ceil((today.getTime() - SEMESTER_START.getTime()) / (1000 * 60 * 60 * 24))
  );
  const semesterProgress = Math.min(100, (semesterElapsedDays / semesterTotalDays) * 100);

  function updateSubject(id: string, field: 'attended' | 'conducted', value: string) {
    const num = parseInt(value, 10);
    setSubjects(prev =>
      prev.map(s => {
        if (s.id !== id) return s;
        const updated = { ...s, [field]: isNaN(num) ? 0 : Math.max(0, num) };
        // Auto-correct: attended can't exceed conducted
        if (field === 'attended' && updated.attended > updated.conducted) {
          updated.conducted = updated.attended;
        }
        return updated;
      })
    );
    setErrors(prev => ({ ...prev, [id]: '' }));
  }

  function validate(): boolean {
    const newErrors: Record<string, string> = {};

    if (!planningDate) {
      newErrors['planningDate'] = 'Please select a planning date.';
    } else {
      const pd = new Date(planningDate);
      if (pd <= today) newErrors['planningDate'] = 'Planning date must be after today.';
      else if (pd > SEMESTER_END)
        newErrors['planningDate'] = 'Planning date cannot be after semester end (29 Nov 2026).';
      else if (pd < SEMESTER_START)
        newErrors['planningDate'] = 'Planning date cannot be before semester start.';
    }

    for (const s of subjects) {
      if (s.attended < 0) newErrors[s.id] = 'Attended cannot be negative.';
      else if (s.conducted < 0) newErrors[s.id] = 'Conducted cannot be negative.';
      else if (s.attended > s.conducted) newErrors[s.id] = 'Attended cannot exceed conducted.';
      else if (s.conducted === 0) newErrors[s.id] = 'Enter at least 1 conducted class.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleGenerate() {
    if (!validate()) return;
    onGenerate({ section, planningDate, subjects });
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F6F8]">
      {/* Hero */}
      <div className="pt-24 pb-10 px-6 text-center">
        <div className="flex justify-center mb-6">
          <Logo size={48} showWordmark={false} />
        </div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs text-emerald-600 font-medium tracking-wide">Demo Data Loaded</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 tracking-tight mb-4" style={{ letterSpacing: '-0.03em' }}>
          Know the risk. <span className="text-emerald-600">Plan ahead.</span>
        </h1>
        <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
          AttendGuard turns your attendance and timetable into a forecast for the rest of your semester.
        </p>
      </div>

      {/* Setup Panel */}
      <div className="flex-1 px-6 pb-16 max-w-5xl mx-auto w-full">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-1">Build your forecast</h2>
          <p className="text-gray-400 text-sm mb-8">
            Tell AttendGuard where you are today. We'll calculate the road ahead.
          </p>

          {/* Config row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Section */}
            <div>
              <label className="text-gray-600 text-sm font-medium mb-2 block">Class Section</label>
              <select
                value={section}
                onChange={e => {
                  setSection(e.target.value);
                  // Update subjects based on selected section
                  const sectionSubjects = SUBJECTS_BY_SECTION[e.target.value] || [];
                  const initial: SubjectInput[] = sectionSubjects.map((name, i) => {
                    const demo = getDemoAttendanceForSubject(name);
                    return { id: `subj-${i}`, name, attended: demo.attended, conducted: demo.conducted };
                  });
                  setSubjects(initial);
                }}
                className="bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 px-3 py-2 text-sm text-gray-900 w-full"
              >
                {SECTIONS.map(s => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            {/* Today */}
            <div>
              <label className="text-gray-600 text-sm font-medium mb-2 block">Today</label>
              <div className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-600 cursor-not-allowed flex items-center gap-2">
                <span className="text-emerald-600 text-xs">●</span>
                <span>
                  {today.toLocaleDateString('en-IN', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">Auto-detected from your system</p>
            </div>

            {/* Planning date */}
            <div>
              <label className="text-gray-600 text-sm font-medium mb-2 block">Plan Until</label>
              <input
                type="date"
                value={planningDate}
                min={today.toISOString().split('T')[0]}
                max={SEMESTER_END.toISOString().split('T')[0]}
                onChange={e => {
                  setPlanningDate(e.target.value);
                  setErrors(prev => ({ ...prev, planningDate: '' }));
                }}
                className="bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 px-3 py-2 text-sm text-gray-900 w-full"
              />
              {errors['planningDate'] && (
                <p className="text-red-600 text-xs mt-1">{errors['planningDate']}</p>
              )}
            </div>
          </div>

          {/* Semester Timeline */}
          <div className="mb-8 p-4 bg-gray-50 rounded-lg border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-gray-400 font-medium">Semester 2026</span>
              <span className="text-xs text-gray-400">
                {semesterProgress.toFixed(0)}% completed
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
              <span>29 Aug</span>
              <div className="flex-1 relative h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="absolute left-0 top-0 h-full bg-emerald-500 rounded-full transition-all duration-700"
                  style={{ width: `${semesterProgress}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white shadow-md shadow-emerald-500/30"
                  style={{ left: `calc(${semesterProgress}% - 6px)` }}
                />
              </div>
              <span>29 Nov</span>
            </div>
            <p className="text-xs text-gray-400 text-center">
              {Math.max(0, Math.ceil((SEMESTER_END.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)))} days remaining
            </p>
          </div>

          {/* Attendance Table */}
          <h3 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-widest text-xs">
            Subject Attendance
          </h3>
          <div className="overflow-x-auto rounded-lg border border-gray-100">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs text-gray-500 font-medium tracking-wider">Subject</th>
                  <th className="text-right px-4 py-3 text-xs text-gray-500 font-medium tracking-wider">Attended</th>
                  <th className="text-right px-4 py-3 text-xs text-gray-500 font-medium tracking-wider">Conducted</th>
                  <th className="text-right px-4 py-3 text-xs text-gray-500 font-medium tracking-wider">%</th>
                  <th className="text-center px-4 py-3 text-xs text-gray-500 font-medium tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody>
                {subjects.map((subj, i) => {
                  const pct = subj.conducted === 0 ? 0 : (subj.attended / subj.conducted) * 100;
                  const risk =
                    pct >= 85 ? 'SAFE' : pct >= 75 ? 'WATCH' : pct >= 60 ? 'AT_RISK' : 'LOW';

                  return (
                    <tr
                      key={subj.id}
                      className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                        i === subjects.length - 1 ? 'border-b-0' : ''
                      }`}
                    >
                      <td className="px-4 py-3 text-gray-700 font-medium text-sm">{subj.name}</td>
                      <td className="px-4 py-3 text-right">
                        <input
                          type="number"
                          value={subj.attended}
                          min={0}
                          max={subj.conducted}
                          onChange={e => updateSubject(subj.id, 'attended', e.target.value)}
                          className="w-16 bg-white border border-gray-200 rounded-xl px-2 py-1 text-sm text-gray-900 text-right focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                        />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <input
                          type="number"
                          value={subj.conducted}
                          min={subj.attended}
                          onChange={e => updateSubject(subj.id, 'conducted', e.target.value)}
                          className="w-16 bg-white border border-gray-200 rounded-xl px-2 py-1 text-sm text-gray-900 text-right focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
                        />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span
                          className={`font-mono text-sm font-semibold ${
                            risk === 'SAFE'
                              ? 'text-emerald-600'
                              : risk === 'WATCH'
                                ? 'text-amber-600'
                                : risk === 'AT_RISK'
                                  ? 'text-orange-600'
                                  : 'text-red-600'
                          }`}
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`inline-block text-xs px-2 py-0.5 rounded font-medium ${
                            risk === 'SAFE'
                              ? 'bg-emerald-500/10 text-emerald-600'
                              : risk === 'WATCH'
                                ? 'bg-amber-500/10 text-amber-600'
                                : risk === 'AT_RISK'
                                  ? 'bg-orange-500/10 text-orange-600'
                                  : 'bg-red-500/10 text-red-600'
                          }`}
                        >
                          {risk === 'AT_RISK' ? 'AT RISK' : risk}
                        </span>
                      </td>
                      {errors[subj.id] && (
                        <td colSpan={5} className="px-4 pb-2 text-red-600 text-xs">
                          {errors[subj.id]}
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* CTA */}
        <div className="flex justify-center">
          <button
            onClick={handleGenerate}
            className="bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-xl text-base px-10 py-4 shadow-md shadow-emerald-500/20 hover:shadow-emerald-500/40 transition-all duration-300"
          >
            Generate Forecast →
          </button>
        </div>
      </div>
    </div>
  );
}
