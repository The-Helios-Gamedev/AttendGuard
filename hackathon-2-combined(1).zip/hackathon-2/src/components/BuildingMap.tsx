import { useState, useEffect, useMemo } from 'react';
import { Building2, Clock, Users, MapPin, Layers, LayoutGrid } from 'lucide-react';
import { BUILDING_FLOORS, getRoomStatus, formatTime, Room } from '../data/rooms';
import RoomDetailModal from './RoomDetailModal';

const FLOOR_LABELS = ['G', '1', '2', '3', '4'];

export function BuildingMap() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [viewMode, setViewMode] = useState<'3D' | 'Grid'>('3D');
  const [activeGridFloor, setActiveGridFloor] = useState<number>(0);
  const [hoveredRoom, setHoveredRoom] = useState<string | null>(null);
  const [focusFloor, setFocusFloor] = useState<number | null>(null);

  // Live clock + auto-refresh room status every second (for countdown precision)
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const stats = useMemo(() => {
    let total = 0;
    let free = 0;
    let occupied = 0;
    BUILDING_FLOORS.forEach(floor => {
      floor.rooms.forEach(room => {
        total++;
        const status = getRoomStatus(room, currentTime);
        if (status.status === 'free') free++;
        else occupied++;
      });
    });
    return { total, free, occupied };
  }, [currentTime]);

  const timeString = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-1 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-emerald-500" />
          IST Block — Room Map
        </h2>
        <p className="text-gray-400 text-sm">
          Find free rooms instantly. Tap any room for countdown & squad invite.
        </p>
      </div>

      {/* Stats Bar */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <Clock className="w-4 h-4 text-emerald-500" />
              <span className="font-mono text-gray-700">{timeString}</span>
            </div>
            <div className="h-5 w-px bg-gray-100" />
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <span className="text-gray-400">Total:</span>
                <span className="text-gray-900 font-semibold">{stats.total}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-emerald-600 font-semibold">{stats.free} Free</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="w-2 h-2 rounded-full bg-red-500" />
                <span className="text-red-600 font-semibold">{stats.occupied} Occupied</span>
              </div>
            </div>
          </div>

          {/* View Toggle */}
          <div className="flex items-center gap-1 bg-gray-50 p-1 rounded-lg border border-gray-100">
            <button
              onClick={() => setViewMode('3D')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                viewMode === '3D'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              3D
            </button>
            <button
              onClick={() => setViewMode('Grid')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                viewMode === 'Grid'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              Grid
            </button>
          </div>
        </div>
      </div>

      {/* === 3D ISOMETRIC VIEW === */}
      {viewMode === '3D' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden" style={{ minHeight: '600px' }}>
          <div className="relative flex">
            {/* Elevator Panel */}
            <div className="flex-shrink-0 w-16 border-r border-gray-100 flex flex-col items-center py-6 gap-3 bg-white">
              <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest mb-2">Floor</div>
              {BUILDING_FLOORS.map((floor, i) => (
                <button
                  key={i}
                  onClick={() => setFocusFloor(focusFloor === i ? null : i)}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold transition-all duration-300 ${
                    focusFloor === i
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30 scale-110'
                      : 'bg-gray-50 text-gray-400 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  {FLOOR_LABELS[i]}
                </button>
              )).reverse()}
            </div>

            {/* 3D Scene */}
            <div className="flex-1 flex items-center justify-center" style={{ perspective: '1800px', minHeight: '580px' }}>
              <style>{`
                @keyframes roomPulse {
                  0%, 100% { box-shadow: inset 0 0 15px rgba(16,185,129,0.15), 0 0 12px rgba(16,185,129,0.3); }
                  50% { box-shadow: inset 0 0 20px rgba(16,185,129,0.25), 0 0 20px rgba(16,185,129,0.5); }
                }
                .room-free { animation: roomPulse 2.5s ease-in-out infinite; }
              `}</style>

              <div
                className="relative transition-all duration-700 ease-out"
                style={{
                  width: '420px',
                  height: '420px',
                  transformStyle: 'preserve-3d',
                  transform: focusFloor !== null
                    ? `rotateX(60deg) rotateZ(-45deg) translateZ(${-focusFloor * 100 + 200}px)`
                    : 'rotateX(60deg) rotateZ(-45deg)',
                }}
              >
                {BUILDING_FLOORS.map((floor, floorIdx) => {
                  const zOffset = floorIdx * 100;
                  const isFaded = focusFloor !== null && focusFloor !== floorIdx;

                  return (
                    <div
                      key={floorIdx}
                      className="absolute inset-0 rounded-xl border transition-all duration-500"
                      style={{
                        transform: `translateZ(${zOffset}px)`,
                        transformStyle: 'preserve-3d',
                        opacity: isFaded ? 0.08 : 1,
                        pointerEvents: isFaded ? 'none' : 'auto',
                        backgroundColor: '#ffffff',
                        borderColor: '#f3f4f6',
                        boxShadow: '0 4px 40px rgba(0,0,0,0.05)',
                      }}
                    >
                      {/* Floor label watermark */}
                      <div className="absolute top-2 left-3 text-[10px] font-bold text-gray-300 uppercase tracking-widest">
                        {floor.label}
                      </div>

                      {/* Room blocks */}
                      <div className="grid gap-2 p-4" style={{
                        gridTemplateColumns: `repeat(${Math.min(floor.rooms.length, floor.rooms.length <= 4 ? floor.rooms.length : Math.ceil(Math.sqrt(floor.rooms.length)))}, 1fr)`,
                        height: '100%',
                        alignContent: 'center',
                      }}>
                        {floor.rooms.map(room => {
                          const status = getRoomStatus(room, currentTime);
                          const isFree = status.status === 'free';
                          const isHovered = hoveredRoom === room.id;

                          return (
                            <div
                              key={room.id}
                              onMouseEnter={() => setHoveredRoom(room.id)}
                              onMouseLeave={() => setHoveredRoom(null)}
                              onClick={() => setSelectedRoom(room)}
                              className={`relative rounded-lg cursor-pointer flex flex-col items-center justify-center p-3 transition-all duration-200 ${
                                isFree ? 'room-free' : ''
                              }`}
                              style={{
                                transformStyle: 'preserve-3d',
                                transform: isHovered ? 'translateZ(30px) scale(1.08)' : 'translateZ(15px)',
                                backgroundColor: isFree ? '#ecfdf5' : '#fef2f2',
                                border: `1px solid ${isFree ? '#6ee7b7' : '#fca5a5'}`,
                                boxShadow: !isFree
                                  ? 'inset 0 0 15px rgba(239,68,68,0.05), 0 0 10px rgba(239,68,68,0.1)'
                                  : undefined,
                                minHeight: '60px',
                              }}
                            >
                              <div className={`font-bold text-sm ${isFree ? 'text-emerald-700' : 'text-red-700'}`}>
                                {room.name.replace('IST ', '')}
                              </div>
                              <div className={`text-[9px] mt-0.5 ${isFree ? 'text-emerald-600/70' : 'text-red-600/70'}`}>
                                {isFree ? (status.freeUntil === 'End of Day' ? 'Free all day' : `→${formatTime(status.freeUntil!)}`) : 'In use'}
                              </div>

                              {/* Hover tooltip */}
                              {isHovered && (
                                <div
                                  className="absolute bg-white border border-gray-100 px-3 py-2 rounded-lg whitespace-nowrap shadow-xl z-50"
                                  style={{
                                    transform: 'rotateZ(45deg) rotateX(-60deg)',
                                    bottom: '110%',
                                    left: '50%',
                                    marginLeft: '-60px',
                                    width: '120px',
                                    textAlign: 'center',
                                  }}
                                >
                                  <div className="font-semibold text-gray-900 text-xs">{room.name}</div>
                                  <div className={`text-[10px] mt-0.5 ${isFree ? 'text-emerald-600' : 'text-red-600'}`}>
                                    {isFree
                                      ? status.freeUntil === 'End of Day'
                                        ? 'Free for the day!'
                                        : `Free until ${formatTime(status.freeUntil!)}`
                                      : `${status.currentClass?.subject}`}
                                  </div>
                                  <div className="text-[9px] text-gray-400 mt-1">Click for details</div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-6 py-4 border-t border-gray-100 bg-gray-50">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-3 h-3 rounded bg-emerald-100 border border-emerald-200" />
              Free — Tap to claim
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-3 h-3 rounded bg-red-100 border border-red-200" />
              Occupied
            </div>
            <div className="text-xs text-gray-400">
              Use floor buttons to isolate a floor • Click any room for countdown
            </div>
          </div>
        </div>
      )}

      {/* === GRID VIEW === */}
      {viewMode === 'Grid' && (
        <div className="space-y-4">
          {/* Floor Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {BUILDING_FLOORS.map((floor, i) => (
              <button
                key={i}
                onClick={() => setActiveGridFloor(i)}
                className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                  activeGridFloor === i
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
                    : 'bg-white text-gray-500 hover:text-gray-900 border border-gray-100 hover:bg-gray-50'
                }`}
              >
                {floor.label}
              </button>
            ))}
          </div>

          {/* Room Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {BUILDING_FLOORS[activeGridFloor]?.rooms.map(room => {
              const status = getRoomStatus(room, currentTime);
              const isFree = status.status === 'free';

              return (
                <div
                  key={room.id}
                  onClick={() => setSelectedRoom(room)}
                  className="bg-white rounded-2xl p-5 cursor-pointer group shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">
                        {room.name}
                      </h3>
                      <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {room.capacity}
                        </span>
                        <span className="capitalize">{room.type}</span>
                      </div>
                    </div>
                    <div
                      className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                        isFree
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-red-50 text-red-700 border border-red-200'
                      }`}
                    >
                      {isFree ? 'FREE' : 'OCCUPIED'}
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-2 h-2 rounded-full ${isFree ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                      <span className="text-sm font-medium text-gray-700">
                        {isFree ? 'Available now' : status.currentClass?.subject || 'In use'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Clock className="w-3 h-3" />
                      <span>
                        {isFree
                          ? status.freeUntil === 'End of Day'
                            ? 'Free for the rest of today'
                            : `Free until ${formatTime(status.freeUntil!)}`
                          : `Ends at ${formatTime(status.currentClass!.endTime)}`}
                      </span>
                    </div>
                    {isFree && status.freeUntil !== 'End of Day' && status.nextClass && (
                      <div className="text-xs text-gray-400 mt-1.5">
                        Next: {status.nextClass.subject} ({status.nextClass.section})
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Room Detail Modal */}
      {selectedRoom && (
        <RoomDetailModal room={selectedRoom} onClose={() => setSelectedRoom(null)} />
      )}
    </div>
  );
}
