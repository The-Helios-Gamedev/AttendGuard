import { SubjectCalc } from '../types';
import { generateInsights } from '../engine/calculator';

interface InsightsPanelProps {
  subjects: SubjectCalc[];
}

export function InsightsPanel({ subjects }: InsightsPanelProps) {
  const insights = generateInsights(subjects);

  const getIcon = (text: string) => {
    if (text.includes('cannot mathematically') || text.includes('Irreversible')) return '⚠';
    if (text.includes('needs attention') || text.includes('at least')) return '●';
    if (text.includes('buffer') || text.includes('can miss')) return '◆';
    return '◇';
  };

  const getColor = (text: string) => {
    if (text.includes('cannot mathematically') || text.includes('Irreversible')) return {
      card: 'bg-red-50 border-red-200',
      icon: 'text-red-600',
      text: 'text-red-800',
    };
    if (text.includes('needs attention') || text.includes('at least')) return {
      card: 'bg-amber-50 border-amber-200',
      icon: 'text-amber-600',
      text: 'text-amber-800',
    };
    return {
      card: 'bg-emerald-50 border-emerald-200',
      icon: 'text-emerald-600',
      text: 'text-emerald-800',
    };
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-1">AttendGuard Insights</h2>
        <p className="text-gray-500 text-sm">
          Predictive Insights — generated from the calculation engine, not guesswork.
        </p>
      </div>

      <div className="space-y-3">
        {insights.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center">
            <p className="text-gray-400 text-sm">No insights to display.</p>
          </div>
        ) : (
          insights.map((insight, i) => {
            const colors = getColor(insight);
            const icon = getIcon(insight);
            return (
              <div
                key={i}
                className={`rounded-xl border p-5 ${colors.card} animate-in`}
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="flex gap-3">
                  <span className={`text-lg leading-none flex-shrink-0 mt-0.5 ${colors.icon}`}>
                    {icon}
                  </span>
                  <p className={`text-sm leading-relaxed ${colors.text}`}>{insight}</p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Summary table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-4">
          Risk Summary
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b border-gray-100">
                <th className="text-left py-2 px-3 text-xs text-gray-500 font-medium rounded-tl-lg">Subject</th>
                <th className="text-right py-2 px-3 text-xs text-gray-500 font-medium">Current</th>
                <th className="text-right py-2 px-3 text-xs text-gray-500 font-medium">Remaining</th>
                <th className="text-right py-2 px-3 text-xs text-gray-500 font-medium">Min for 75%</th>
                <th className="text-right py-2 px-3 text-xs text-gray-500 font-medium">Max Possible</th>
                <th className="text-center py-2 px-3 text-xs text-gray-500 font-medium rounded-tr-lg">Risk</th>
              </tr>
            </thead>
            <tbody>
              {subjects.map(s => (
                <tr key={s.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-3 text-gray-700 font-medium text-xs">{s.name}</td>
                  <td className="py-3 px-3 text-right font-mono text-xs">
                    <span
                      className={
                        s.risk === 'SAFE'
                          ? 'text-emerald-600'
                          : s.risk === 'WATCH'
                            ? 'text-amber-600'
                            : s.risk === 'AT_RISK'
                              ? 'text-orange-600'
                              : 'text-red-600'
                      }
                    >
                      {s.percentage.toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right text-gray-500 text-xs">{s.remaining}</td>
                  <td className="py-3 px-3 text-right text-xs">
                    {s.isIrreversible ? (
                      <span className="text-red-500">N/A</span>
                    ) : (
                      <span className="text-gray-600">{s.minRequired75}</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-xs text-gray-500">
                    {s.maxPossible.toFixed(1)}%
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`text-xs px-2 py-0.5 rounded font-medium ${
                        s.risk === 'SAFE'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : s.risk === 'WATCH'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : s.risk === 'AT_RISK'
                              ? 'bg-orange-50 text-orange-700 border border-orange-200'
                              : 'bg-red-50 text-red-700 border border-red-200'
                      }`}
                    >
                      {s.risk === 'AT_RISK' ? 'AT RISK' : s.risk}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
