import { useState, useEffect, useCallback } from 'react';
import { X, Clock, Users, Share2, MessageCircle, CheckCircle, AlertCircle, Timer, MapPin } from 'lucide-react';
import { Room, getRoomStatus, getTodaySchedule, formatTime, RoomScheduleSlot } from '../data/rooms';

interface RoomDetailModalProps {
  room: Room;
  onClose: () => void;
}

function formatCountdown(ms: number): string {
  if (ms <= 0) return '00:00:00';
  const h = Math.floor(ms / 3600000).toString().padStart(2, '0');
  const m = Math.floor((ms % 3600000) / 60000).toString().padStart(2, '0');
  const s = Math.floor((ms % 60000) / 1000).toString().padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function timeStringToDate(timeStr: string): Date {
  const [h, m] = timeStr.split(':').map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d;
}

export default function RoomDetailModal({ room, onClose }: RoomDetailModalProps) {
  const [claimed, setClaimed] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [progress, setProgress] = useState(100);
  const [squadClicked, setSquadClicked] = useState(false);

  const now = new Date();
  const status = getRoomStatus(room, now);
  const todaySchedule = getTodaySchedule(room, now);
  const isFree = status.status === 'free';

  // Compute countdown target
  const getCountdownTarget = useCallback((): Date | null => {
    if (isFree) {
      // Count down to when the next class starts
      if (status.freeUntil && status.freeUntil !== 'End of Day') {
        return timeStringToDate(status.freeUntil);
      }
      return null; // Free all day
    } else {
      // Count down to when current class ends
      if (status.currentClass) {
        return timeStringToDate(status.currentClass.endTime);
      }
      return null;
    }
  }, [isFree, status]);

  // Live countdown every second
  useEffect(() => {
    const tick = () => {
      const target = getCountdownTarget();
      if (target) {
        const diff = target.getTime() - Date.now();
        setTimeLeft(Math.max(0, diff));
        // Progress: calculate based on a sensible baseline
        const totalDuration = 50 * 60 * 1000; // 50-minute class period baseline
        setProgress(Math.max(0, Math.min(100, (Math.max(0, diff) / totalDuration) * 100)));
      } else {
        setTimeLeft(0);
        setProgress(100);
      }
    };

    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [getCountdownTarget]);

  // Disable body scroll
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = 'unset'; };
  }, []);

  // WhatsApp share
  const freeUntilText = status.freeUntil === 'End of Day'
    ? 'for the rest of today'
    : status.freeUntil
      ? `until ${formatTime(status.freeUntil)}`
      : 'now';

  const shareText = `📍 Heading to ${room.name}. It's free ${freeUntilText}. Come fast!`;
  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;

  const handleCallSquad = () => {
    setSquadClicked(true);
    window.open(whatsappUrl, '_blank');
    setTimeout(() => setSquadClicked(false), 2000);
  };

  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const statusColor = isFree ? 'text-emerald-600' : 'text-red-600';
  const ringStroke = isFree ? 'text-emerald-500' : 'text-red-500';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative z-10 w-full max-w-xl bg-white border border-gray-100 rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        style={{ animation: 'slideUp 0.3s ease-out forwards' }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-full transition-colors z-20"
        >
          <X size={20} />
        </button>

        <div className="flex-1 overflow-y-auto">
          {/* Header */}
          <div className="px-6 pt-6 pb-5 border-b border-gray-100">
            <div className="flex items-start justify-between pr-10">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{room.name}</h2>
                <div className="flex items-center gap-3 mt-2 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Users size={14} />
                    {room.capacity} seats
                  </span>
                  <span className="px-2 py-0.5 text-xs bg-gray-50 border border-gray-100 rounded capitalize">{room.type}</span>
                  <span className="flex items-center gap-1">
                    <MapPin size={14} />
                    Floor {room.floor === 0 ? 'G' : room.floor}
                  </span>
                </div>
              </div>
              <div
                className={`px-3 py-1.5 rounded-lg border text-sm font-bold flex items-center gap-1.5 ${
                  isFree
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                    : 'border-red-200 bg-red-50 text-red-700'
                }`}
              >
                {isFree ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
                {isFree ? 'AVAILABLE' : 'OCCUPIED'}
              </div>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* ===== COUNTDOWN TIMER ===== */}
            <div
              className={`relative flex flex-col items-center py-8 px-6 rounded-2xl border overflow-hidden ${
                isFree
                  ? 'border-emerald-200 bg-gradient-to-b from-emerald-50 to-transparent'
                  : 'border-red-200 bg-gradient-to-b from-red-50 to-transparent'
              }`}
              style={{
                boxShadow: isFree
                  ? '0 0 40px rgba(16,185,129,0.05)'
                  : '0 0 40px rgba(239,68,68,0.05)',
              }}
            >
              <div className={`text-sm font-medium mb-4 flex items-center gap-2 ${statusColor}`}>
                <Timer size={16} />
                {isFree
                  ? status.freeUntil === 'End of Day'
                    ? 'Free for the rest of today! 🎉'
                    : 'Free for'
                  : 'Class ends in'}
              </div>

              {(status.freeUntil !== 'End of Day' || !isFree) && (
                <div className="relative w-52 h-52 flex items-center justify-center mb-3">
                  {/* Progress Ring */}
                  <svg className="absolute w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50" cy="50" r="44"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-gray-100"
                    />
                    <circle
                      cx="50" cy="50" r="44"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeDasharray="276.5"
                      strokeDashoffset={276.5 - (276.5 * Math.min(progress, 100)) / 100}
                      className={`${ringStroke} transition-all duration-1000 ease-linear`}
                    />
                  </svg>

                  {/* Time Display */}
                  <div className={`text-4xl font-mono font-bold tracking-tight ${statusColor}`}>
                    {formatCountdown(timeLeft)}
                  </div>
                </div>
              )}

              {status.freeUntil === 'End of Day' && isFree && (
                <div className="text-5xl mb-2">🎉</div>
              )}

              {/* Sub-info */}
              {isFree && status.nextClass && (
                <div className="text-xs text-gray-500 mt-2">
                  Next: {status.nextClass.subject} (Section {status.nextClass.section}) at {formatTime(status.nextClass.startTime)}
                </div>
              )}
              {!isFree && status.currentClass && (
                <div className="text-xs text-gray-500 mt-2">
                  {status.currentClass.subject} — Section {status.currentClass.section}
                </div>
              )}
            </div>

            {/* ===== CLAIM & SQUAD BUTTONS ===== */}
            {isFree && (
              <div className="space-y-3">
                {!claimed ? (
                  <button
                    onClick={() => setClaimed(true)}
                    className="w-full py-3.5 bg-gray-50 hover:bg-gray-100 border border-gray-100 rounded-xl font-medium text-gray-700 transition-all active:scale-[0.98] text-sm"
                  >
                    🏃 I'm heading here!
                  </button>
                ) : (
                  <div className="text-center py-3 text-emerald-700 font-medium bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-center gap-2 text-sm">
                    <CheckCircle size={16} />
                    You claimed this room ✓
                  </div>
                )}

                {/* Call the Squad */}
                <button
                  onClick={handleCallSquad}
                  className={`w-full group relative flex items-center justify-center gap-3 py-4 rounded-xl font-bold text-lg shadow-sm transition-all active:scale-[0.98] ${
                    squadClicked
                      ? 'bg-emerald-600 text-white shadow-emerald-500/30'
                      : 'bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white'
                  }`}
                >
                  <MessageCircle size={22} className="group-hover:scale-110 transition-transform" />
                  {squadClicked ? '✓ Opening WhatsApp...' : '📱 Call the Squad'}
                </button>

                {/* Message preview */}
                <div className="flex items-start gap-2 text-xs text-gray-400 bg-gray-50 rounded-lg p-3 border border-gray-100">
                  <Share2 size={12} className="mt-0.5 flex-shrink-0" />
                  <span>"{shareText}"</span>
                </div>
              </div>
            )}

            {/* ===== TODAY'S SCHEDULE TIMELINE ===== */}
            <div>
              <h3 className="text-sm font-semibold text-gray-600 mb-4 flex items-center gap-2 uppercase tracking-widest">
                <Clock size={14} className="text-emerald-500" />
                Today's Schedule
              </h3>

              {todaySchedule.length === 0 ? (
                <div className="text-gray-500 text-sm italic py-4 text-center bg-gray-50 rounded-lg border border-gray-100">
                  No classes scheduled today — it's all yours! 🎉
                </div>
              ) : (
                <div className="relative border-l-2 border-gray-100 ml-2 pl-5 space-y-4">
                  {todaySchedule.map((slot, idx) => {
                    const [sH, sM] = slot.startTime.split(':').map(Number);
                    const [eH, eM] = slot.endTime.split(':').map(Number);
                    const startMin = sH * 60 + sM;
                    const endMin = eH * 60 + eM;

                    const isPast = currentMinutes >= endMin;
                    const isCurrent = currentMinutes >= startMin && currentMinutes < endMin;

                    return (
                      <div key={idx} className="relative">
                        {/* Timeline dot */}
                        <div
                          className={`absolute -left-[25px] w-3 h-3 rounded-full border-2 ${
                            isCurrent
                              ? 'bg-emerald-500 border-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse'
                              : isPast
                                ? 'bg-white border-gray-200'
                                : 'bg-white border-gray-300'
                          }`}
                        />

                        <div
                          className={`p-3 rounded-lg border transition-all ${
                            isCurrent
                              ? 'bg-emerald-50 border-emerald-200'
                              : isPast
                                ? 'bg-gray-50 border-transparent opacity-60'
                                : 'bg-gray-50 border-gray-100'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className={`font-mono text-xs font-semibold ${isCurrent ? 'text-emerald-600' : 'text-gray-500'}`}>
                              {formatTime(slot.startTime)} – {formatTime(slot.endTime)}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider bg-emerald-100 px-2 py-0.5 rounded">
                                Now
                              </span>
                            )}
                          </div>
                          <div className={`text-sm font-medium ${isPast ? 'text-gray-400' : 'text-gray-900'}`}>
                            {slot.subject}
                          </div>
                          <div className={`text-xs mt-0.5 ${isPast ? 'text-gray-400' : 'text-gray-500'}`}>
                            Section {slot.section}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
