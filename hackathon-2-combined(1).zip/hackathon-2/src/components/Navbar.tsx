import { Logo } from './Logo';
import { RiskLevel } from '../types';
import { SECTIONS } from '../data/timetable';

interface NavbarProps {
  activeTab: string;
  onTabChange: (tab: 'forecast' | 'planner' | 'insights' | 'roommap' | 'smartsearch') => void;
  section: string;
  onSectionChange: (section: string) => void;
  showTabs: boolean;
  overallRisk?: RiskLevel;
  username?: string;
  onLogout?: () => void;
}

export function Navbar({
  activeTab,
  onTabChange,
  section,
  onSectionChange,
  showTabs,
  overallRisk,
  username,
  onLogout,
}: NavbarProps) {
  const tabs: Array<{ key: 'forecast' | 'planner' | 'insights' | 'roommap' | 'smartsearch'; label: string }> = [
    { key: 'forecast', label: 'Dashboard' },
    { key: 'planner', label: 'Planner' },
    { key: 'insights', label: 'Insights' },
    { key: 'roommap', label: '📍 Room Map' },
    { key: 'smartsearch', label: '✨ AI Room Finder' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-14 flex items-center px-6 border-b border-gray-200 bg-white/90 backdrop-blur-md shadow-sm">
      {/* Logo */}
      <div className="flex-shrink-0">
        <Logo size={28} showWordmark />
      </div>

      {/* Center tabs */}
      {showTabs && (
        <div className="flex-1 flex items-center justify-center gap-1">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => onTabChange(tab.key)}
              className={`px-4 py-1.5 text-sm rounded-md transition-all duration-200 font-medium ${
                activeTab === tab.key
                  ? 'text-emerald-700 bg-emerald-50'
                  : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* Right controls */}
      <div className="flex items-center gap-3 ml-auto">
        {showTabs && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">Section</span>
            <select
              value={section}
              onChange={e => onSectionChange(e.target.value)}
              className="bg-white border border-gray-200 rounded-md px-2.5 py-1 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 cursor-pointer"
            >
              {SECTIONS.map(s => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Status indicator */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gray-50 border border-gray-100">
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              overallRisk === 'IRREVERSIBLE'
                ? 'bg-red-500'
                : overallRisk === 'AT_RISK'
                  ? 'bg-orange-500'
                  : overallRisk === 'WATCH'
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
            } animate-pulse`}
          />
          <span className="text-xs text-gray-500 font-medium tracking-wide">
            Prediction Engine Active
          </span>
        </div>

        {username && (
          <div className="flex items-center gap-2 pl-3 border-l border-gray-200">
            <span className="text-xs text-gray-600 font-medium">{username}</span>
            {onLogout && (
              <button
                onClick={onLogout}
                className="text-xs font-medium text-gray-500 hover:text-red-500 transition-colors"
              >
                Log out
              </button>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
