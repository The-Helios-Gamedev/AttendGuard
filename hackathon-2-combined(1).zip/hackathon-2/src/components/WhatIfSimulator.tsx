import { SubjectCalc } from '../types';
import { projectedAttendance } from '../engine/calculator';

interface WhatIfSimulatorProps {
  subjects: SubjectCalc[];
  whatIfClasses: number;
  onWhatIfChange: (n: number) => void;
}

export function WhatIfSimulator({ subjects, whatIfClasses, onWhatIfChange }: WhatIfSimulatorProps) {
  const options = [0, 1, 2, 3, 5, 10, 15, 20];

  // Calc what-if overall
  const totalAttended = subjects.reduce((s, x) => s + x.attended, 0);
  const totalConducted = subjects.reduce((s, x) => s + x.conducted, 0);
  const totalRemaining = subjects.reduce((s, x) => s + x.remaining, 0);

  // Exactly distribute whatIfClasses across subjects to guarantee exact sum
  let futureAtt = 0;
  let remainingClassesToDistribute = whatIfClasses;
  
  // Sort subjects by highest remaining to give them classes first (fair distribution)
  const sortedSubjects = [...subjects].sort((a, b) => b.remaining - a.remaining);
  
  while (remainingClassesToDistribute > 0 && sortedSubjects.some(s => s.remaining > 0)) {
    for (const s of sortedSubjects) {
      if (remainingClassesToDistribute > 0 && s.remaining > 0) {
        // give 1 class
        s.remaining -= 1; // temporarily mutate for calculation
        futureAtt += 1;
        remainingClassesToDistribute -= 1;
      }
    }
  }

  // Restore original remaining values since we mutated them for the loop above
  sortedSubjects.forEach(s => {
    const original = subjects.find(x => x.id === s.id);
    if(original) s.remaining = original.remaining;
  });
  const displayPct = projectedAttendance(totalAttended, totalConducted, totalRemaining, futureAtt);

  const currentPct =
    totalConducted === 0 ? 0 : (totalAttended / totalConducted) * 100;

  const delta = displayPct - currentPct;

  const risk =
    displayPct >= 85
      ? 'SAFE'
      : displayPct >= 75
        ? 'WATCH'
        : 'AT_RISK';

  const riskConfig = {
    SAFE: { label: 'Safe', color: '#059669' }, // emerald-600
    WATCH: { label: 'Watch', color: '#d97706' }, // amber-600
    AT_RISK: { label: 'At Risk', color: '#ea580c' }, // orange-600
  };

  const dist75 = displayPct - 75;
  const dist90 = displayPct - 90;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-1">What if?</h2>
        <p className="text-gray-400 text-sm">
          What happens if you attend your next <strong className="text-gray-500">N</strong> classes?
        </p>
      </div>

      {/* Class selector */}
      <div className="flex flex-wrap gap-2 mb-8">
        {options.map(n => (
          <button
            key={n}
            onClick={() => onWhatIfChange(n)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border ${
              whatIfClasses === n
                ? 'bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-900/10'
                : 'bg-gray-50 border-gray-100 text-gray-500 hover:text-gray-700 hover:bg-gray-100'
            }`}
          >
            {n === 0 ? 'Skip all' : `${n} class${n !== 1 ? 'es' : ''}`}
          </button>
        ))}
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-xs text-gray-400">Custom:</span>
          <input
            type="number"
            min={0}
            max={totalRemaining}
            value={whatIfClasses}
            onChange={e => {
              const v = parseInt(e.target.value, 10);
              if (!isNaN(v)) onWhatIfChange(Math.max(0, Math.min(totalRemaining, v)));
            }}
            className="w-16 bg-white border border-gray-200 rounded-xl px-2 py-1.5 text-sm text-gray-700 text-center focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500 transition-colors"
          />
        </div>
      </div>

      {/* Results */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {/* Projected attendance */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 col-span-2 md:col-span-1">
          <p className="label-subtle mb-2 text-gray-500">Projected Attendance</p>
          <p
            className="text-3xl font-bold tracking-tight"
            style={{ color: riskConfig[risk].color, letterSpacing: '-0.03em' }}
          >
            {displayPct.toFixed(1)}%
          </p>
          <p className={`text-xs mt-1 font-medium ${delta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {delta >= 0 ? '+' : ''}{delta.toFixed(1)}% from current
          </p>
        </div>

        {/* Risk status */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-4">
          <p className="label-subtle mb-2 text-gray-500">Risk Status</p>
          <p
            className="text-xl font-bold"
            style={{ color: riskConfig[risk].color }}
          >
            {riskConfig[risk].label}
          </p>
        </div>

        {/* Distance from 75% */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-4">
          <p className="label-subtle mb-2 text-gray-500">From 75%</p>
          <p className={`text-xl font-bold ${dist75 >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {dist75 >= 0 ? '+' : ''}{dist75.toFixed(1)}%
          </p>
        </div>

        {/* Distance from 90% */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-4">
          <p className="label-subtle mb-2 text-gray-500">From 90%</p>
          <p className={`text-xl font-bold ${dist90 >= 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
            {dist90 >= 0 ? '+' : ''}{dist90.toFixed(1)}%
          </p>
        </div>
      </div>

      {/* Visual bar */}
      <div className="relative">
        <div className="flex justify-between text-xs text-gray-400 mb-2">
          <span>0%</span>
          <span className="text-emerald-600/80">75%</span>
          <span className="text-emerald-600/80">90%</span>
          <span>100%</span>
        </div>
        <div className="h-4 bg-gray-100 rounded-full overflow-hidden relative">
          {/* 75% threshold marker */}
          <div className="absolute left-[75%] top-0 bottom-0 w-px bg-emerald-500/40 z-10" />
          {/* 90% marker */}
          <div className="absolute left-[90%] top-0 bottom-0 w-px bg-emerald-500/40 z-10" />
          {/* Before bar */}
          <div
            className="absolute h-full bg-gray-200 rounded-full"
            style={{ width: `${Math.min(100, currentPct)}%` }}
          />
          {/* After bar (what-if) */}
          <div
            className="absolute h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.min(100, displayPct)}%`,
              background: riskConfig[risk].color,
              opacity: 0.9,
            }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-400 mt-1.5">
          <span>Current: {currentPct.toFixed(1)}%</span>
          <span>Projected: {displayPct.toFixed(1)}%</span>
        </div>
      </div>

      {/* Per-subject impact */}
      <div className="mt-6 pt-6 border-t border-gray-100">
        <p className="text-xs text-gray-400 mb-3 uppercase tracking-widest">Impact per subject</p>
        <div className="space-y-2">
          {subjects.map((s, idx) => {
            // Re-run the exact distribution algorithm per subject to get its specific share
            let share = 0;
            let tempRemainingToDistribute = whatIfClasses;
            const tempSubjects = subjects.map(sub => ({ ...sub }));
            const tempSorted = [...tempSubjects].sort((a, b) => b.remaining - a.remaining);
            
            while (tempRemainingToDistribute > 0 && tempSorted.some(sub => sub.remaining > 0)) {
              for (const sub of tempSorted) {
                if (tempRemainingToDistribute > 0 && sub.remaining > 0) {
                  if (sub.id === s.id) share++;
                  sub.remaining -= 1;
                  tempRemainingToDistribute -= 1;
                }
              }
            }

            const proj = projectedAttendance(s.attended, s.conducted, s.remaining, share);
            const diff = proj - s.percentage;
            return (
              <div key={s.id} className="flex items-center gap-3">
                <span className="text-xs text-gray-500 w-44 flex-shrink-0 truncate">{s.name}</span>
                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      proj >= 85 ? 'bg-emerald-500' : proj >= 75 ? 'bg-amber-500' : 'bg-orange-500'
                    }`}
                    style={{ width: `${Math.min(100, proj)}%` }}
                  />
                </div>
                <span className="text-xs font-mono text-gray-600 w-12 text-right">
                  {proj.toFixed(0)}%
                </span>
                <span className={`text-xs font-mono w-12 text-right ${diff >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {diff >= 0 ? '+' : ''}{diff.toFixed(1)}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
