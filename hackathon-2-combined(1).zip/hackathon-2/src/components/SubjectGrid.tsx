import { SubjectCalc, RiskLevel } from '../types';

const RISK_CONFIG: Record<RiskLevel, { label: string; textClass: string; bgClass: string; borderClass: string; dot: string }> = {
  SAFE: {
    label: 'Safe',
    textClass: 'text-emerald-600',
    bgClass: 'bg-emerald-500/10',
    borderClass: 'border-emerald-200',
    dot: 'bg-emerald-500',
  },
  WATCH: {
    label: 'Watch',
    textClass: 'text-amber-600',
    bgClass: 'bg-amber-500/10',
    borderClass: 'border-amber-200',
    dot: 'bg-amber-500',
  },
  AT_RISK: {
    label: 'At Risk',
    textClass: 'text-orange-600',
    bgClass: 'bg-orange-500/10',
    borderClass: 'border-orange-200',
    dot: 'bg-orange-500',
  },
  IRREVERSIBLE: {
    label: 'Irreversible',
    textClass: 'text-red-600',
    bgClass: 'bg-red-500/10',
    borderClass: 'border-red-200',
    dot: 'bg-red-500',
  },
};

interface SubjectCardProps {
  subject: SubjectCalc;
  isSelected: boolean;
  onClick: () => void;
}

function SubjectCard({ subject: s, isSelected, onClick }: SubjectCardProps) {
  const rc = RISK_CONFIG[s.risk];

  return (
    <button
      onClick={onClick}
      className={`w-full text-left bg-white rounded-2xl shadow-sm border p-5 transition-all duration-200 cursor-pointer ${
        isSelected ? 'border-emerald-500/40 bg-emerald-500/5 ring-1 ring-emerald-500/20' : 'border-gray-100 hover:border-gray-200 hover:shadow-md'
      }`}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-gray-900 font-medium text-sm leading-tight">{s.name}</p>
          <p className="text-xs text-gray-500 mt-0.5">
            {s.attended}/{s.conducted} classes
          </p>
        </div>
        <span
          className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium border ${rc.textClass} ${rc.bgClass} ${rc.borderClass}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${rc.dot}`} />
          {rc.label}
        </span>
      </div>

      {/* Numbers */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <p className="text-gray-500 text-xs font-medium mb-1">Current</p>
          <p className={`text-xl font-bold tracking-tight ${rc.textClass}`}>
            {s.percentage.toFixed(1)}%
          </p>
        </div>
        <div>
          <p className="text-gray-500 text-xs font-medium mb-1">Max Possible</p>
          <p className="text-xl font-bold tracking-tight text-gray-600">
            {s.maxPossible.toFixed(1)}%
          </p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-1 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            s.risk === 'SAFE'
              ? 'bg-emerald-500'
              : s.risk === 'WATCH'
                ? 'bg-amber-500'
                : s.risk === 'AT_RISK'
                  ? 'bg-orange-500'
                  : 'bg-red-500'
          }`}
          style={{ width: `${Math.min(100, s.percentage)}%` }}
        />
      </div>

      {/* Action line */}
      <div className="mt-3">
        {s.isIrreversible ? (
          <p className="text-xs text-red-600/80">
            Cannot reach 75% — max possible: {s.maxPossible.toFixed(1)}%
          </p>
        ) : s.risk === 'SAFE' && s.canMissAndStaySafe > 0 ? (
          <p className="text-xs text-emerald-600/80">
            Can miss {s.canMissAndStaySafe} class{s.canMissAndStaySafe !== 1 ? 'es' : ''} and stay above 75%
          </p>
        ) : s.minRequired75 > 0 ? (
          <p className="text-xs text-amber-600/80">
            Attend {s.minRequired75} of next {s.remaining} classes to stay above 75%
          </p>
        ) : (
          <p className="text-xs text-emerald-600/80">
            On track — {s.remaining} classes remaining
          </p>
        )}
      </div>
    </button>
  );
}

interface SubjectDetailProps {
  subject: SubjectCalc;
  onClose: () => void;
}

function SubjectDetail({ subject: s, onClose }: SubjectDetailProps) {
  const rc = RISK_CONFIG[s.risk];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-in">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <p className="text-gray-500 text-xs font-medium mb-1">Subject Detail</p>
          <h3 className="text-xl font-bold text-gray-900 tracking-tight">{s.name}</h3>
          <span
            className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium border mt-2 ${rc.textClass} ${rc.bgClass} ${rc.borderClass}`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${rc.dot}`} />
            {rc.label}
          </span>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 text-2xl leading-none transition-colors w-8 h-8 flex items-center justify-center"
        >
          ×
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Current', value: `${s.percentage.toFixed(1)}%`, accent: rc.textClass },
          { label: 'Attended', value: s.attended.toString(), accent: 'text-gray-900' },
          { label: 'Conducted', value: s.conducted.toString(), accent: 'text-gray-600' },
          { label: 'Remaining', value: s.remaining.toString(), accent: 'text-gray-600' },
        ].map(item => (
          <div key={item.label} className="bg-gray-50 rounded-lg p-3 border border-gray-100">
            <p className="text-gray-500 text-xs font-medium mb-1">{item.label}</p>
            <p className={`text-2xl font-bold tracking-tight ${item.accent}`}>{item.value}</p>
          </div>
        ))}
      </div>

      {/* Irreversible alert */}
      {s.isIrreversible && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 mb-6">
          <p className="text-red-700 font-semibold text-sm mb-1">IRREVERSIBLE DETENTION</p>
          <p className="text-red-600/80 text-xs">
            Even with perfect attendance from now until the end of the semester, reaching 75% is
            mathematically impossible.
          </p>
          <div className="grid grid-cols-3 gap-3 mt-4">
            {[
              { label: 'Current', value: `${s.percentage.toFixed(1)}%` },
              { label: 'Max Possible', value: `${s.maxPossible.toFixed(1)}%` },
              { label: 'Required', value: '75.0%' },
            ].map(item => (
              <div key={item.label} className="text-center">
                <p className="text-xs text-red-500 mb-1">{item.label}</p>
                <p className="text-sm font-bold text-red-700">{item.value}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-red-700/80 text-center mt-3 font-semibold">● STATUS: IRREVERSIBLE</p>
        </div>
      )}

      {/* Path to safety */}
      {!s.isIrreversible && (
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 mb-6">
          <h4 className="text-sm font-semibold text-gray-700 mb-4">Your path to safety</h4>
          <div className="space-y-3">
            {[
              {
                label: 'To stay above 75%',
                value: `Attend at least ${s.minRequired75} of ${s.remaining} classes`,
                note:
                  s.minRequired75 === 0
                    ? `✓ Already safe — can miss ${s.canMissAndStaySafe} more`
                    : null,
              },
              {
                label: 'To reach 90%',
                value:
                  s.minRequired90 >= s.remaining
                    ? `Attend all ${s.remaining} classes`
                    : `Attend at least ${s.minRequired90} of ${s.remaining} classes`,
                note: null,
              },
              {
                label: 'Max possible attendance',
                value: `${s.maxPossible.toFixed(1)}%`,
                note: '(if all remaining classes attended)',
              },
            ].map(item => (
              <div key={item.label} className="flex items-start justify-between gap-4 py-2 border-b border-gray-200 last:border-0">
                <p className="text-xs text-gray-500 flex-shrink-0">{item.label}</p>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{item.value}</p>
                  {item.note && <p className="text-xs text-gray-400 mt-0.5">{item.note}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Visual progress bar */}
      <div>
        <div className="flex justify-between text-xs text-gray-400 mb-2">
          <span>0%</span>
          <span>75%</span>
          <span>90%</span>
          <span>100%</span>
        </div>
        <div className="relative h-3 bg-gray-100 rounded-full overflow-hidden">
          {/* 75% marker */}
          <div className="absolute left-[75%] top-0 bottom-0 w-px bg-emerald-500/40" />
          {/* 90% marker */}
          <div className="absolute left-[90%] top-0 bottom-0 w-px bg-emerald-600/40" />
          {/* Current */}
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              s.risk === 'SAFE'
                ? 'bg-emerald-500'
                : s.risk === 'WATCH'
                  ? 'bg-amber-500'
                  : s.risk === 'AT_RISK'
                    ? 'bg-orange-500'
                    : 'bg-red-500'
            }`}
            style={{ width: `${Math.min(100, s.percentage)}%` }}
          />
        </div>
      </div>
    </div>
  );
}

interface SubjectGridProps {
  subjects: SubjectCalc[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}

export function SubjectGrid({ subjects, selectedId, onSelect }: SubjectGridProps) {
  const selected = subjects.find(s => s.id === selectedId) ?? null;

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-gray-900">Subject Analysis</h2>

      {/* Selected detail */}
      {selected && (
        <SubjectDetail
          subject={selected}
          onClose={() => onSelect(null)}
        />
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map(s => (
          <SubjectCard
            key={s.id}
            subject={s}
            isSelected={s.id === selectedId}
            onClick={() => onSelect(s.id === selectedId ? null : s.id)}
          />
        ))}
      </div>
    </div>
  );
}
