import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import { ForecastPoint, RiskLevel } from '../types';

interface ForecastChartProps {
  points: ForecastPoint[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; payload: ForecastPoint }>;
  label?: string;
}

const RISK_COLORS: Record<RiskLevel, string> = {
  SAFE: '#059669',
  WATCH: '#d97706',
  AT_RISK: '#ea580c',
  IRREVERSIBLE: '#dc2626',
};

function CustomTooltip({ active, payload }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  const data = payload[0].payload as ForecastPoint;
  const pct = data.percentage;
  const risk = data.risk;

  const riskLabels: Record<RiskLevel, string> = {
    SAFE: 'Safe',
    WATCH: 'Watch',
    AT_RISK: 'At Risk',
    IRREVERSIBLE: 'Irreversible',
  };

  return (
    <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm min-w-[180px]">
      <p className="text-gray-500 text-xs mb-2 font-medium">{data.dateLabel}</p>
      <p
        className="text-2xl font-bold mb-2 tracking-tight"
        style={{ color: RISK_COLORS[risk], letterSpacing: '-0.02em' }}
      >
        {pct.toFixed(1)}%
      </p>
      <div className="space-y-1 text-xs text-gray-400">
        <p>Attended: <span className="text-gray-600">{data.attended}</span></p>
        <p>Conducted: <span className="text-gray-600">{data.conducted}</span></p>
      </div>
      <div className="mt-2 pt-2 border-t border-gray-100">
        <span
          className="text-xs font-semibold px-2 py-0.5 rounded"
          style={{
            color: RISK_COLORS[risk],
            background: `${RISK_COLORS[risk]}18`,
            border: `1px solid ${RISK_COLORS[risk]}30`,
          }}
        >
          {riskLabels[risk]}
        </span>
      </div>
    </div>
  );
}

export function ForecastChart({ points }: ForecastChartProps) {
  if (!points.length) return null;

  const minY = Math.max(0, Math.min(...points.map(p => p.percentage)) - 5);
  const maxY = Math.min(100, Math.max(...points.map(p => p.percentage)) + 5);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Attendance Forecast</h2>
          <p className="text-xs text-gray-400 mt-0.5">
            CURRENT → FORECAST → SEMESTER END
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-px bg-emerald-500 inline-block" />
            <span>75% Detention</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-px bg-emerald-600 inline-block" />
            <span>90% Target</span>
          </div>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={points} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="pctGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
              <stop offset="95%" stopColor="#10b981" stopOpacity={0.01} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
          <XAxis
            dataKey="dateLabel"
            tick={{ fill: '#9ca3af', fontSize: 11 }}
            axisLine={{ stroke: '#f3f4f6' }}
            tickLine={false}
            interval="preserveStartEnd"
          />
          <YAxis
            domain={[Math.floor(minY), Math.ceil(maxY)]}
            tick={{ fill: '#9ca3af', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: number) => `${v}%`}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine
            y={75}
            stroke="#10b981"
            strokeWidth={1}
            strokeDasharray="6 3"
            label={{ value: '75%', fill: '#10b981', fontSize: 11, position: 'insideBottomRight' }}
          />
          <ReferenceLine
            y={90}
            stroke="#059669"
            strokeWidth={1}
            strokeDasharray="6 3"
            label={{ value: '90%', fill: '#059669', fontSize: 11, position: 'insideTopRight' }}
          />
          <Area
            type="monotone"
            dataKey="percentage"
            stroke="#10b981"
            strokeWidth={2}
            fill="url(#pctGradient)"
            dot={false}
            activeDot={{ r: 5, fill: '#10b981', strokeWidth: 0 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
