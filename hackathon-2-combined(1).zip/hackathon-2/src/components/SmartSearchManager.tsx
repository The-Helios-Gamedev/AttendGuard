import { useState, useMemo, useEffect } from 'react';
import { Search, Sparkles, MapPin, Wind, Monitor, PenTool, Users, Clock, AlertCircle } from 'lucide-react';
import { BUILDING_FLOORS, getRoomStatus, formatTime, Room } from '../data/rooms';
import RoomDetailModal from './RoomDetailModal';

// NLP Parser Simulation
function parseAIQuery(query: string) {
  const q = query.toLowerCase();
  
  // 1. Duration (in minutes)
  let durationMinutes = 0;
  const hourMatch = q.match(/(\d+)\s*hour/);
  const minMatch = q.match(/(\d+)\s*min/);
  if (hourMatch) durationMinutes += parseInt(hourMatch[1]) * 60;
  if (minMatch) durationMinutes += parseInt(minMatch[1]);
  
  // 2. Floor
  let targetFloor: number | null = null;
  if (q.includes('ground')) targetFloor = 0;
  else if (q.includes('first') || q.includes('1st')) targetFloor = 1;
  else if (q.includes('second') || q.includes('2nd')) targetFloor = 2;
  else if (q.includes('third') || q.includes('3rd')) targetFloor = 3;
  else if (q.includes('fourth') || q.includes('4th')) targetFloor = 4;
  
  // 3. Amenities
  const amenities: string[] = [];
  if (q.includes('ac') || q.includes('air condition')) amenities.push('AC');
  if (q.includes('projector')) amenities.push('Projector');
  if (q.includes('whiteboard') || q.includes('board')) amenities.push('Whiteboard');
  
  // 4. Capacity
  let minCapacity = 0;
  const peopleMatch = q.match(/(\d+)\s*(people|team|students)/);
  if (peopleMatch) {
    minCapacity = parseInt(peopleMatch[1]);
  } else if (q.includes('team') || q.includes('group')) {
    minCapacity = 4; // default team size assumption
  }
  
  return { durationMinutes, targetFloor, amenities, minCapacity };
}

function getMinutesFromMidnight(date: Date) {
  return date.getHours() * 60 + date.getMinutes();
}

function timeStringToMinutes(timeStr: string) {
  if (timeStr === 'End of Day') return 24 * 60;
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

export function SmartSearchManager() {
  const [query, setQuery] = useState('');
  const [activeQuery, setActiveQuery] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  // Auto refresh time
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 10000);
    return () => clearInterval(timer);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveQuery(query);
  };

  const parsedParams = useMemo(() => parseAIQuery(activeQuery), [activeQuery]);

  const filteredFloors = useMemo(() => {
    const currentMins = getMinutesFromMidnight(currentTime);
    
    return BUILDING_FLOORS.map(floorData => {
      // 1. Floor filter
      if (parsedParams.targetFloor !== null && floorData.floor !== parsedParams.targetFloor) {
        return { ...floorData, rooms: [] };
      }

      // 2. Room filters
      const matchingRooms = floorData.rooms.filter(room => {
        // Capacity check
        if (room.capacity < parsedParams.minCapacity) return false;
        
        // Amenities check
        const roomAmenities = room.amenities || [];
        for (const am of parsedParams.amenities) {
          if (!roomAmenities.includes(am)) return false;
        }

        // Availability check
        const status = getRoomStatus(room, currentTime);
        if (status.status !== 'free') return false; // Must be empty right now
        
        // Duration check
        if (parsedParams.durationMinutes > 0 && status.freeUntil) {
          const freeUntilMins = timeStringToMinutes(status.freeUntil);
          const durationAvailable = freeUntilMins - currentMins;
          if (durationAvailable < parsedParams.durationMinutes) {
            return false;
          }
        }
        
        return true;
      });

      return { ...floorData, rooms: matchingRooms };
    }).filter(f => f.rooms.length > 0);
  }, [currentTime, parsedParams]);

  const totalFound = filteredFloors.reduce((acc, f) => acc + f.rooms.length, 0);

  const renderAmenityIcon = (am: string) => {
    switch (am) {
      case 'AC': return <Wind className="w-3 h-3" />;
      case 'Projector': return <Monitor className="w-3 h-3" />;
      case 'Whiteboard': return <PenTool className="w-3 h-3" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-8 animate-fade">
      {/* Hero Search Section */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 md:p-12 text-center relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-emerald-50 to-transparent opacity-50 pointer-events-none" />
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-emerald-100 rounded-full blur-3xl opacity-50 pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-600 font-medium text-sm mb-6 border border-emerald-100 shadow-sm">
            <Sparkles className="w-4 h-4" />
            AI Room Finder
          </div>
          <h1 className="text-3xl md:text-5xl font-bold text-gray-900 tracking-tight mb-4">
            Find the perfect space, <span className="text-emerald-500">instantly.</span>
          </h1>
          <p className="text-gray-500 mb-8 max-w-xl mx-auto">
            Describe what you need in natural language. We'll scan the timetables and find empty rooms that match your exact requirements.
          </p>

          <form onSubmit={handleSearch} className="relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="h-6 w-6 text-gray-400 group-focus-within:text-emerald-500 transition-colors" />
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., I need an AC room on the ground floor for a team of 4 for the next 2 hours"
              className="w-full bg-white border-2 border-gray-200 rounded-2xl py-5 pl-14 pr-32 text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all text-lg shadow-sm"
            />
            <button
              type="submit"
              className="absolute right-3 top-3 bottom-3 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 rounded-xl transition-all shadow-md hover:shadow-lg shadow-emerald-500/30"
            >
              Search
            </button>
          </form>
          
          {/* Example chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-6">
            <span className="text-xs text-gray-400 font-medium mr-2">Try asking:</span>
            {["AC room for 2 hours", "Projector on 3rd floor", "Empty lab for 5 people"].map((example, i) => (
              <button
                key={i}
                onClick={() => { setQuery(example); setActiveQuery(example); }}
                className="text-xs bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-600 px-3 py-1.5 rounded-full transition-colors"
              >
                {example}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Section (The Floor Grid) */}
      {activeQuery && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-500" />
              Available Floor Grid
            </h2>
            <div className="text-sm font-medium text-gray-500 bg-white px-4 py-1.5 rounded-full border border-gray-200 shadow-sm">
              Found <span className="text-emerald-600 font-bold">{totalFound}</span> empty rooms
            </div>
          </div>

          {/* Parsed active filters display */}
          <div className="flex flex-wrap gap-2 mb-6">
            {parsedParams.targetFloor !== null && (
              <div className="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-lg border border-indigo-100 flex items-center gap-1.5">
                Floor: {parsedParams.targetFloor === 0 ? 'Ground' : parsedParams.targetFloor}
              </div>
            )}
            {parsedParams.durationMinutes > 0 && (
              <div className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-semibold rounded-lg border border-blue-100 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                Min {parsedParams.durationMinutes} mins free
              </div>
            )}
            {parsedParams.minCapacity > 0 && (
              <div className="px-3 py-1 bg-amber-50 text-amber-700 text-xs font-semibold rounded-lg border border-amber-100 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                {parsedParams.minCapacity}+ people
              </div>
            )}
            {parsedParams.amenities.map(am => (
              <div key={am} className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-lg border border-emerald-100 flex items-center gap-1.5">
                {renderAmenityIcon(am)}
                {am}
              </div>
            ))}
          </div>

          {totalFound === 0 ? (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
              <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">No matching rooms found right now.</h3>
              <p className="text-gray-500 text-sm">
                Try adjusting your criteria or checking back later. All other rooms are currently occupied or don't match your filters.
              </p>
            </div>
          ) : (
            <div className="space-y-8">
              {filteredFloors.map(floor => (
                <div key={floor.floor} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="font-bold text-gray-900 text-lg">{floor.label}</h3>
                    <span className="text-xs font-semibold bg-white border border-gray-200 text-gray-600 px-2.5 py-1 rounded-full shadow-sm">
                      {floor.rooms.length} room{floor.rooms.length !== 1 ? 's' : ''} free
                    </span>
                  </div>
                  
                  <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {floor.rooms.map(room => {
                      const status = getRoomStatus(room, currentTime);
                      return (
                        <div
                          key={room.id}
                          onClick={() => setSelectedRoom(room)}
                          className="group bg-white border border-gray-100 hover:border-emerald-200 rounded-xl p-5 cursor-pointer transition-all hover:shadow-md hover:shadow-emerald-500/5 relative overflow-hidden"
                        >
                          <div className="absolute top-0 left-0 w-1 h-full bg-emerald-400 transform origin-left transition-transform scale-y-0 group-hover:scale-y-100" />
                          
                          <div className="flex justify-between items-start mb-3">
                            <h4 className="font-bold text-gray-900 text-lg group-hover:text-emerald-600 transition-colors">
                              {room.name}
                            </h4>
                            <span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-1 rounded border border-emerald-100 uppercase tracking-wider">
                              Free Now
                            </span>
                          </div>

                          <div className="space-y-2 mb-4">
                            <div className="flex items-center gap-2 text-xs text-gray-500 font-medium">
                              <Clock className="w-3.5 h-3.5 text-gray-400" />
                              {status.freeUntil === 'End of Day' 
                                ? 'Free for the rest of the day' 
                                : `Free until ${formatTime(status.freeUntil!)}`}
                            </div>
                            <div className="flex items-center gap-2 text-xs text-gray-500 font-medium">
                              <Users className="w-3.5 h-3.5 text-gray-400" />
                              Capacity: {room.capacity}
                            </div>
                          </div>

                          {/* Amenities */}
                          {room.amenities && room.amenities.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 pt-3 border-t border-gray-50">
                              {room.amenities.map(am => (
                                <span key={am} className="inline-flex items-center gap-1 bg-gray-50 border border-gray-100 text-gray-600 text-[10px] px-2 py-0.5 rounded-full font-medium">
                                  {renderAmenityIcon(am)}
                                  {am}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {selectedRoom && (
        <RoomDetailModal room={selectedRoom} onClose={() => setSelectedRoom(null)} />
      )}
    </div>
  );
}
