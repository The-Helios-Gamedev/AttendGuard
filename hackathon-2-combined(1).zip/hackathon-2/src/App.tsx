import { useState, useCallback } from 'react';
import { SubjectInput, DashboardData, RiskLevel } from './types';
import { buildDashboard } from './engine/calculator';
import { Navbar } from './components/Navbar';
import { SetupPanel } from './components/SetupPanel';
import { OverviewPanel } from './components/OverviewPanel';
import { ForecastChart } from './components/ForecastChart';
import { SubjectGrid } from './components/SubjectGrid';
import { WhatIfSimulator } from './components/WhatIfSimulator';
import { Planner } from './components/Planner';
import { InsightsPanel } from './components/InsightsPanel';
import { IrreversibleBanner } from './components/IrreversibleBanner';
import { BuildingMap } from './components/BuildingMap';
import { SmartSearchManager } from './components/SmartSearchManager';
import { LoginPanel } from './components/LoginPanel';
import { SUBJECTS_BY_SECTION, getDemoAttendanceForSubject } from './data/timetable';

type ActiveTab = 'forecast' | 'planner' | 'insights' | 'roommap' | 'smartsearch';

export default function App() {
  const [view, setView] = useState<'login' | 'setup' | 'dashboard'>('login');
  const [username, setUsername] = useState<string>('');
  const [section, setSection] = useState('II-BME');
  const [planningDate, setPlanningDate] = useState('');
  const [subjects, setSubjects] = useState<SubjectInput[]>([]);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [whatIfClasses, setWhatIfClasses] = useState(5);
  const [activeTab, setActiveTab] = useState<ActiveTab>('forecast');

  const handleLogin = (user: string, userSection: string) => {
    setUsername(user);
    setSection(userSection);
    setView('setup');
  };

  const handleGenerate = useCallback(
    (data: { section: string; planningDate: string; subjects: SubjectInput[] }) => {
      const today = new Date();
      const planDate = new Date(data.planningDate);

      const dash = buildDashboard(data.section, data.subjects, today, planDate);

      setSection(data.section);
      setPlanningDate(data.planningDate);
      setSubjects(data.subjects);
      setDashboard(dash);
      setView('dashboard');
      setActiveTab('forecast');
      setSelectedSubjectId(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    []
  );

  const handleSectionChange = useCallback(
    (newSection: string) => {
      if (!planningDate || subjects.length === 0) return;
      // Subjects differ per section, so reload them for the new section
      const newSubjects: SubjectInput[] = (SUBJECTS_BY_SECTION[newSection] || []).map((name, i) => {
        const demo = getDemoAttendanceForSubject(name);
        return { id: `subj-${i}`, name, attended: demo.attended, conducted: demo.conducted };
      });
      setSection(newSection);
      setSubjects(newSubjects);
      setSelectedSubjectId(null);
      setDashboard(buildDashboard(newSection, newSubjects, new Date(), new Date(planningDate)));
    },
    [planningDate, subjects]
  );

  const handleLogout = () => {
    setUsername('');
    setDashboard(null);
    setSubjects([]);
    setPlanningDate('');
    setSelectedSubjectId(null);
    setActiveTab('forecast');
    setView('login');
  };

  const overallRisk: RiskLevel | undefined = dashboard
    ? dashboard.overallAttendance >= 85
      ? 'SAFE'
      : dashboard.overallAttendance >= 75
        ? 'WATCH'
        : dashboard.overallAttendance >= 60
          ? 'AT_RISK'
          : 'IRREVERSIBLE'
    : undefined;

  if (view === 'login') {
    return <LoginPanel onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#F5F6F8] text-gray-900">
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        section={section}
        onSectionChange={handleSectionChange}
        showTabs={view === 'dashboard'}
        overallRisk={overallRisk}
        username={username}
        onLogout={handleLogout}
      />

      <main className="pt-14">
        {view === 'setup' ? (
          <SetupPanel onGenerate={handleGenerate} userSection={section} />
        ) : (
          dashboard && (
            <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
              {/* Overview always visible */}
              <OverviewPanel
                data={dashboard}
                onSubjectClick={setSelectedSubjectId}
              />

              {/* Tab content */}
              {activeTab === 'forecast' && (
                <div className="space-y-8 animate-fade">
                  <IrreversibleBanner subjects={dashboard.subjects} />
                  <ForecastChart points={dashboard.forecastPoints} />
                  <SubjectGrid
                    subjects={dashboard.subjects}
                    selectedId={selectedSubjectId}
                    onSelect={setSelectedSubjectId}
                  />
                  <WhatIfSimulator
                    subjects={dashboard.subjects}
                    whatIfClasses={whatIfClasses}
                    onWhatIfChange={setWhatIfClasses}
                  />
                </div>
              )}

              {activeTab === 'planner' && (
                <div className="animate-fade">
                  <Planner
                    section={section}
                    subjects={dashboard.subjects}
                    currentPlanningDate={planningDate}
                  />
                </div>
              )}

              {activeTab === 'insights' && (
                <div className="animate-fade">
                  <InsightsPanel subjects={dashboard.subjects} />
                </div>
              )}

              {activeTab === 'roommap' && (
                <div className="animate-fade">
                  <BuildingMap />
                </div>
              )}

              {activeTab === 'smartsearch' && (
                <div className="animate-fade">
                  <SmartSearchManager />
                </div>
              )}

              {/* Back to setup */}
              <div className="pt-4 pb-8 flex justify-center">
                <button
                  onClick={() => setView('setup')}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
                >
                  ← Edit attendance data
                </button>
              </div>
            </div>
          )
        )}
      </main>
    </div>
  );
}
