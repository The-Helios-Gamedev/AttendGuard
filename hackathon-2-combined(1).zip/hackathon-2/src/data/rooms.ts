// ============================================================
// ROOM AVAILABILITY DATA — IST Block Building
// Deterministic schedules for consistent display
// ============================================================

export interface RoomScheduleSlot {
  startTime: string; // 'HH:MM' 24-hour format
  endTime: string;
  subject: string;
  section: string; // 'A', 'B', etc.
}

export interface Room {
  id: string;        // e.g. 'IST-509'
  name: string;      // e.g. 'IST 509'
  floor: number;     // 0-4
  type: 'classroom' | 'lab' | 'seminar';
  capacity: number;
  amenities?: string[];
  schedule: Record<string, RoomScheduleSlot[]>; // key = 'monday' | 'tuesday' | ...
}

export interface FloorData {
  floor: number;
  label: string;
  rooms: Room[];
}

// ---- Time Helpers ----

export function formatTime(time: string): string {
  const [hours, minutes] = time.split(':').map(Number);
  const period = hours >= 12 ? 'PM' : 'AM';
  const hours12 = hours % 12 || 12;
  return `${hours12}:${minutes.toString().padStart(2, '0')} ${period}`;
}

function getDayName(date: Date): string {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  return days[date.getDay()];
}

function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

// ---- Room Status Engine ----

export interface RoomStatusResult {
  status: 'free' | 'occupied';
  currentClass?: RoomScheduleSlot;
  nextClass?: RoomScheduleSlot;
  freeUntil?: string; // 'HH:MM' or 'End of Day'
}

export function getRoomStatus(room: Room, now: Date): RoomStatusResult {
  const dayName = getDayName(now);

  // Weekends / Sunday — always free
  if (dayName === 'sunday') {
    return { status: 'free', freeUntil: 'End of Day' };
  }

  const scheduleToday = room.schedule[dayName] || [];
  if (scheduleToday.length === 0) {
    return { status: 'free', freeUntil: 'End of Day' };
  }

  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // Before first class
  if (currentMinutes < timeToMinutes(scheduleToday[0].startTime)) {
    return {
      status: 'free',
      nextClass: scheduleToday[0],
      freeUntil: scheduleToday[0].startTime,
    };
  }

  // Check each slot
  for (let i = 0; i < scheduleToday.length; i++) {
    const slot = scheduleToday[i];
    const start = timeToMinutes(slot.startTime);
    const end = timeToMinutes(slot.endTime);

    if (currentMinutes >= start && currentMinutes < end) {
      // Currently in this class
      const nextSlot = scheduleToday[i + 1] || undefined;
      return {
        status: 'occupied',
        currentClass: slot,
        nextClass: nextSlot,
      };
    }

    // Between this class and next
    if (i < scheduleToday.length - 1) {
      const nextSlot = scheduleToday[i + 1];
      const nextStart = timeToMinutes(nextSlot.startTime);
      if (currentMinutes >= end && currentMinutes < nextStart) {
        return {
          status: 'free',
          nextClass: nextSlot,
          freeUntil: nextSlot.startTime,
        };
      }
    }
  }

  // After last class
  return { status: 'free', freeUntil: 'End of Day' };
}

export function getTodaySchedule(room: Room, now: Date): RoomScheduleSlot[] {
  const dayName = getDayName(now);
  return room.schedule[dayName] || [];
}

// ---- Helpers ----

export function getAllRooms(): Room[] {
  return BUILDING_FLOORS.flatMap(f => f.rooms);
}

// ---- Building Data (Deterministic Schedules) ----

const S = {
  DS: 'Data Structures',
  OS: 'Operating Systems',
  CN: 'Computer Networks',
  OOP: 'Object Oriented Programming',
  DBMS: 'Database Management Systems',
  MATH: 'Mathematics',
};

// Ground Floor — Labs & Seminar
const groundFloorRooms: Room[] = [
  {
    id: 'IST-101', name: 'IST 101', floor: 0, type: 'lab', capacity: 60, amenities: ["Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '11:50', subject: S.DS + ' Lab', section: 'A' }],
      tuesday:   [{ startTime: '13:30', endTime: '16:00', subject: S.CN + ' Lab', section: 'B' }],
      wednesday: [{ startTime: '09:00', endTime: '11:50', subject: S.OS + ' Lab', section: 'C' }],
      thursday:  [{ startTime: '13:30', endTime: '16:00', subject: S.OOP + ' Lab', section: 'A' }],
      friday:    [{ startTime: '09:00', endTime: '11:50', subject: S.DBMS + ' Lab', section: 'D' }],
    },
  },
  {
    id: 'IST-102', name: 'IST 102', floor: 0, type: 'lab', capacity: 60, amenities: ["AC","Projector"],
    schedule: {
      monday:    [{ startTime: '13:30', endTime: '16:00', subject: S.OOP + ' Lab', section: 'E' }],
      tuesday:   [{ startTime: '09:00', endTime: '11:50', subject: S.DS + ' Lab', section: 'F' }],
      wednesday: [{ startTime: '13:30', endTime: '16:00', subject: S.CN + ' Lab', section: 'G' }],
      thursday:  [],
      friday:    [{ startTime: '13:30', endTime: '16:00', subject: S.OS + ' Lab', section: 'H' }],
    },
  },
  {
    id: 'IST-103', name: 'IST 103', floor: 0, type: 'seminar', capacity: 200, amenities: ["AC","Projector","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [{ startTime: '11:00', endTime: '12:40', subject: 'Guest Lecture', section: 'All' }],
      wednesday: [],
      thursday:  [{ startTime: '09:00', endTime: '10:40', subject: 'Department Seminar', section: 'All' }],
      friday:    [],
    },
  },
];

// 1st Floor — Busy classrooms (Sections A–D)
const firstFloorRooms: Room[] = [
  {
    id: 'IST-201', name: 'IST 201', floor: 1, type: 'classroom', capacity: 60, amenities: ["AC","Projector","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'A' }, { startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'A' }, { startTime: '13:30', endTime: '14:20', subject: S.MATH, section: 'A' }, { startTime: '14:20', endTime: '15:10', subject: S.CN, section: 'A' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.MATH, section: 'A' }, { startTime: '11:00', endTime: '11:50', subject: S.DBMS, section: 'A' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'A' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'A' }, { startTime: '09:50', endTime: '10:40', subject: S.OOP, section: 'A' }, { startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'A' }],
      thursday:  [{ startTime: '09:00', endTime: '09:50', subject: S.OS, section: 'A' }, { startTime: '11:00', endTime: '11:50', subject: S.DS, section: 'A' }, { startTime: '14:20', endTime: '15:10', subject: S.DBMS, section: 'A' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'A' }, { startTime: '09:50', endTime: '10:40', subject: S.CN, section: 'A' }, { startTime: '13:30', endTime: '14:20', subject: S.OS, section: 'A' }],
    },
  },
  {
    id: 'IST-202', name: 'IST 202', floor: 1, type: 'classroom', capacity: 60, amenities: ["AC","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'B' }, { startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'B' }, { startTime: '14:20', endTime: '15:10', subject: S.DS, section: 'B' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'B' }, { startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'B' }, { startTime: '13:30', endTime: '14:20', subject: S.DBMS, section: 'B' }],
      wednesday: [{ startTime: '11:00', endTime: '11:50', subject: S.DBMS, section: 'B' }, { startTime: '13:30', endTime: '14:20', subject: S.CN, section: 'B' }],
      thursday:  [{ startTime: '09:00', endTime: '09:50', subject: S.OOP, section: 'B' }, { startTime: '09:50', endTime: '10:40', subject: S.CN, section: 'B' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'B' }],
      friday:    [{ startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'B' }, { startTime: '13:30', endTime: '14:20', subject: S.DS, section: 'B' }, { startTime: '15:10', endTime: '16:00', subject: S.OOP, section: 'B' }],
    },
  },
  {
    id: 'IST-203', name: 'IST 203', floor: 1, type: 'classroom', capacity: 60, amenities: ["AC"],
    schedule: {
      monday:    [{ startTime: '09:50', endTime: '10:40', subject: S.OOP, section: 'C' }, { startTime: '11:00', endTime: '11:50', subject: S.DBMS, section: 'C' }, { startTime: '15:10', endTime: '16:00', subject: S.CN, section: 'C' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'C' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'C' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.MATH, section: 'C' }, { startTime: '09:50', endTime: '10:40', subject: S.DS, section: 'C' }, { startTime: '13:30', endTime: '14:20', subject: S.OS, section: 'C' }],
      thursday:  [{ startTime: '11:00', endTime: '11:50', subject: S.OS, section: 'C' }, { startTime: '11:50', endTime: '12:40', subject: S.OOP, section: 'C' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DBMS, section: 'C' }, { startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'C' }, { startTime: '14:20', endTime: '15:10', subject: S.DS, section: 'C' }],
    },
  },
  {
    id: 'IST-204', name: 'IST 204', floor: 1, type: 'classroom', capacity: 60, amenities: ["AC"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.MATH, section: 'D' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'D' }],
      tuesday:   [{ startTime: '09:50', endTime: '10:40', subject: S.OOP, section: 'D' }, { startTime: '11:00', endTime: '11:50', subject: S.DS, section: 'D' }, { startTime: '15:10', endTime: '16:00', subject: S.CN, section: 'D' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.OS, section: 'D' }, { startTime: '11:50', endTime: '12:40', subject: S.DBMS, section: 'D' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'D' }],
      thursday:  [{ startTime: '09:50', endTime: '10:40', subject: S.CN, section: 'D' }, { startTime: '13:30', endTime: '14:20', subject: S.MATH, section: 'D' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.OOP, section: 'D' }, { startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'D' }],
    },
  },
];

// 2nd Floor — Sections E–H
const secondFloorRooms: Room[] = [
  {
    id: 'IST-301', name: 'IST 301', floor: 2, type: 'classroom', capacity: 60, amenities: ["Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DBMS, section: 'E' }, { startTime: '11:00', endTime: '11:50', subject: S.CN, section: 'E' }, { startTime: '14:20', endTime: '15:10', subject: S.OS, section: 'E' }],
      tuesday:   [{ startTime: '09:50', endTime: '10:40', subject: S.MATH, section: 'E' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'E' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'E' }, { startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'E' }, { startTime: '15:10', endTime: '16:00', subject: S.DBMS, section: 'E' }],
      thursday:  [{ startTime: '11:00', endTime: '11:50', subject: S.DBMS, section: 'E' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'E' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'E' }, { startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'E' }],
    },
  },
  {
    id: 'IST-302', name: 'IST 302', floor: 2, type: 'classroom', capacity: 60, amenities: ["AC","Projector","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'F' }, { startTime: '13:30', endTime: '14:20', subject: S.DS, section: 'F' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'F' }, { startTime: '11:00', endTime: '11:50', subject: S.CN, section: 'F' }, { startTime: '14:20', endTime: '15:10', subject: S.DBMS, section: 'F' }],
      wednesday: [{ startTime: '11:00', endTime: '11:50', subject: S.OOP, section: 'F' }, { startTime: '13:30', endTime: '14:20', subject: S.MATH, section: 'F' }],
      thursday:  [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'F' }, { startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'F' }],
      friday:    [{ startTime: '11:50', endTime: '12:40', subject: S.DBMS, section: 'F' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'F' }, { startTime: '15:10', endTime: '16:00', subject: S.CN, section: 'F' }],
    },
  },
  {
    id: 'IST-303', name: 'IST 303', floor: 2, type: 'classroom', capacity: 60, amenities: ["Projector","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'G' }, { startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'G' }],
      tuesday:   [{ startTime: '09:50', endTime: '10:40', subject: S.OS, section: 'G' }, { startTime: '13:30', endTime: '14:20', subject: S.DBMS, section: 'G' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'G' }],
      thursday:  [{ startTime: '11:00', endTime: '11:50', subject: S.MATH, section: 'G' }, { startTime: '14:20', endTime: '15:10', subject: S.OOP, section: 'G' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.OS, section: 'G' }, { startTime: '09:50', endTime: '10:40', subject: S.DS, section: 'G' }, { startTime: '15:10', endTime: '16:00', subject: S.DBMS, section: 'G' }],
    },
  },
  {
    id: 'IST-304', name: 'IST 304', floor: 2, type: 'classroom', capacity: 60, amenities: ["AC","Projector","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '11:00', endTime: '11:50', subject: S.CN, section: 'H' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'H' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.DBMS, section: 'H' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'H' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'H' }],
      thursday:  [{ startTime: '09:00', endTime: '09:50', subject: S.CN, section: 'H' }, { startTime: '11:00', endTime: '11:50', subject: S.OS, section: 'H' }],
      friday:    [{ startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'H' }, { startTime: '14:20', endTime: '15:10', subject: S.DBMS, section: 'H' }],
    },
  },
];

// 3rd Floor — Sections I–J + one spare
const thirdFloorRooms: Room[] = [
  {
    id: 'IST-401', name: 'IST 401', floor: 3, type: 'classroom', capacity: 60, amenities: ["AC","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.OOP, section: 'I' }, { startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'I' }],
      tuesday:   [{ startTime: '09:50', endTime: '10:40', subject: S.CN, section: 'I' }, { startTime: '11:00', endTime: '11:50', subject: S.DS, section: 'I' }],
      wednesday: [{ startTime: '13:30', endTime: '14:20', subject: S.DBMS, section: 'I' }, { startTime: '14:20', endTime: '15:10', subject: S.OS, section: 'I' }],
      thursday:  [{ startTime: '09:00', endTime: '09:50', subject: S.MATH, section: 'I' }, { startTime: '11:00', endTime: '11:50', subject: S.CN, section: 'I' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'I' }, { startTime: '13:30', endTime: '14:20', subject: S.OOP, section: 'I' }],
    },
  },
  {
    id: 'IST-402', name: 'IST 402', floor: 3, type: 'classroom', capacity: 60, amenities: ["AC","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:50', endTime: '10:40', subject: S.MATH, section: 'J' }, { startTime: '11:00', endTime: '11:50', subject: S.DBMS, section: 'J' }],
      tuesday:   [{ startTime: '09:00', endTime: '09:50', subject: S.OOP, section: 'J' }, { startTime: '13:30', endTime: '14:20', subject: S.CN, section: 'J' }],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.OS, section: 'J' }, { startTime: '09:50', endTime: '10:40', subject: S.DS, section: 'J' }],
      thursday:  [{ startTime: '14:20', endTime: '15:10', subject: S.DBMS, section: 'J' }, { startTime: '15:10', endTime: '16:00', subject: S.MATH, section: 'J' }],
      friday:    [{ startTime: '11:00', endTime: '11:50', subject: S.CN, section: 'J' }, { startTime: '14:20', endTime: '15:10', subject: S.OS, section: 'J' }],
    },
  },
  {
    id: 'IST-403', name: 'IST 403', floor: 3, type: 'classroom', capacity: 60, amenities: ["Whiteboard"],
    schedule: {
      monday:    [{ startTime: '11:00', endTime: '11:50', subject: S.OS, section: 'I' }],
      tuesday:   [],
      wednesday: [{ startTime: '09:00', endTime: '09:50', subject: S.MATH, section: 'J' }],
      thursday:  [],
      friday:    [{ startTime: '15:10', endTime: '16:00', subject: S.DBMS, section: 'I' }],
    },
  },
];

// 4th Floor — Light schedules, lots of free rooms (the sweet spots!)
const fourthFloorRooms: Room[] = [
  {
    id: 'IST-501', name: 'IST 501', floor: 4, type: 'classroom', capacity: 40, amenities: ["Projector","Whiteboard"],
    schedule: {
      monday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DS, section: 'E' }],
      tuesday:   [],
      wednesday: [{ startTime: '14:20', endTime: '15:10', subject: S.CN, section: 'F' }],
      thursday:  [],
      friday:    [],
    },
  },
  {
    id: 'IST-502', name: 'IST 502', floor: 4, type: 'classroom', capacity: 40, amenities: ["AC","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [{ startTime: '11:00', endTime: '11:50', subject: S.OS, section: 'G' }],
      wednesday: [],
      thursday:  [{ startTime: '09:50', endTime: '10:40', subject: S.OOP, section: 'H' }],
      friday:    [],
    },
  },
  {
    id: 'IST-503', name: 'IST 503', floor: 4, type: 'classroom', capacity: 40, amenities: ["AC","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [],
      wednesday: [],
      thursday:  [{ startTime: '13:30', endTime: '14:20', subject: S.MATH, section: 'I' }],
      friday:    [{ startTime: '09:00', endTime: '09:50', subject: S.DBMS, section: 'J' }],
    },
  },
  {
    id: 'IST-504', name: 'IST 504', floor: 4, type: 'classroom', capacity: 40, amenities: ["Projector"],
    schedule: {
      monday:    [{ startTime: '14:20', endTime: '15:10', subject: S.DBMS, section: 'A' }],
      tuesday:   [],
      wednesday: [],
      thursday:  [],
      friday:    [],
    },
  },
  {
    id: 'IST-505', name: 'IST 505', floor: 4, type: 'classroom', capacity: 40, amenities: ["AC","Projector","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [],
      wednesday: [{ startTime: '11:00', endTime: '11:50', subject: S.DS, section: 'B' }],
      thursday:  [],
      friday:    [],
    },
  },
  {
    id: 'IST-506', name: 'IST 506', floor: 4, type: 'classroom', capacity: 40, amenities: ["Projector","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [{ startTime: '15:10', endTime: '16:00', subject: S.CN, section: 'C' }],
      wednesday: [],
      thursday:  [],
      friday:    [],
    },
  },
  {
    id: 'IST-507', name: 'IST 507', floor: 4, type: 'classroom', capacity: 40, amenities: ["AC","Projector"],
    schedule: {
      monday:    [],
      tuesday:   [],
      wednesday: [],
      thursday:  [],
      friday:    [{ startTime: '14:20', endTime: '15:10', subject: S.MATH, section: 'D' }],
    },
  },
  {
    id: 'IST-508', name: 'IST 508', floor: 4, type: 'classroom', capacity: 40, amenities: ["Projector"],
    schedule: {
      monday:    [],
      tuesday:   [],
      wednesday: [],
      thursday:  [],
      friday:    [],
    },
  },
  {
    id: 'IST-509', name: 'IST 509', floor: 4, type: 'classroom', capacity: 40, amenities: ["Projector","Whiteboard"],
    schedule: {
      monday:    [],
      tuesday:   [],
      wednesday: [],
      thursday:  [],
      friday:    [],
    },
  },
];

// ---- Exported Building Data ----

export const BUILDING_FLOORS: FloorData[] = [
  { floor: 0, label: 'Ground Floor', rooms: groundFloorRooms },
  { floor: 1, label: '1st Floor', rooms: firstFloorRooms },
  { floor: 2, label: '2nd Floor', rooms: secondFloorRooms },
  { floor: 3, label: '3rd Floor', rooms: thirdFloorRooms },
  { floor: 4, label: '4th Floor', rooms: fourthFloorRooms },
];
