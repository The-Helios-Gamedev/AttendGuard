const fs = require('fs');
let c = fs.readFileSync('src/components/Navbar.tsx', 'utf8');
c = c.replace(/key: 'forecast' \| 'planner' \| 'insights' \| 'roommap'/g, "key: 'forecast' | 'planner' | 'insights' | 'roommap' | 'smartsearch'");
fs.writeFileSync('src/components/Navbar.tsx', c);
