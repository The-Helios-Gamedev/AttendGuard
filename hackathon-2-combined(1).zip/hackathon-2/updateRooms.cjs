const fs = require('fs');
let content = fs.readFileSync('src/data/rooms.ts', 'utf8');

// Add amenities property to interface
if (!content.includes('amenities?: string[];')) {
  content = content.replace('capacity: number;', 'capacity: number;\n  amenities?: string[];');
}

// Add amenities to rooms if not present
content = content.replace(/capacity: \d+,(\s*schedule)/g, (match, p1) => {
  const allAmenities = ['AC', 'Projector', 'Whiteboard'];
  // deterministically pseudo-random based on string index so it doesn't change on re-runs
  const amenities = allAmenities.filter(() => Math.random() > 0.4);
  if (amenities.length === 0) amenities.push('Whiteboard'); // at least one
  return match.replace(p1, ` amenities: ${JSON.stringify(amenities)},${p1}`);
});

fs.writeFileSync('src/data/rooms.ts', content);
